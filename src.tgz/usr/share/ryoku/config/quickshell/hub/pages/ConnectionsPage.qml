pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Shapes
import Quickshell
import Quickshell.Io
import Quickshell.Networking
import Quickshell.Bluetooth
import Ryoku.Ui
import Ryoku.Ui.Singletons
import "../Singletons"

// Connections (SYSTEM). A self-contained, full-bleed pluggable page: its own
// head, a bone-pill tab strip (Wi-Fi / Ethernet / Bluetooth / Hotspot / VPN /
// DNS / Phone), and a Loader that swaps between the three live subtabs drawn
// here; Ethernet, VPN, DNS and Phone live in their own files (fileTabs). Every
// backend is a system tool -- the Quickshell Networking/Bluetooth services plus
// nmcli/bluetoothctl, and the shell daemon for Ethernet, VPN and DNS -- so the page
// applies immediately; Bluetooth power also records the user's choice.
// The subtab bodies are
// process wiring, identical logic; only the presentation is recast to
// monochrome. State is by word and inversion, never colour; signal strength is
// drawn in ink bars. The Loader destroys the outgoing tab on every switch, so
// each body re-reads system state on construction and stops its own scan on
// destruction, exactly as the old three-file version did.
Item {
    id: pg

    property var hub
    readonly property bool fullBleed: true

    property string sub: "wifi"
    function acceptRequestedSub() {
        if (!pg.hub)
            return;
        var requested = String(pg.hub.connectionSub || "");
        if (requested === "")
            return;
        pg.sub = requested;
        Qt.callLater(function() {
            if (pg.hub && pg.hub.connectionSub === requested)
                pg.hub.connectionSub = "";
        });
    }
    onHubChanged: Qt.callLater(function() { pg.acceptRequestedSub(); })
    Component.onCompleted: Qt.callLater(function() { pg.acceptRequestedSub(); })
    Connections {
        target: pg.hub || null
        ignoreUnknownSignals: true
        function onConnectionSubChanged() { Qt.callLater(pg.acceptRequestedSub); }
    }

    readonly property var tabs: [
        { "key": "wifi", "label": I18n.tr("Wi-Fi") },
        { "key": "ethernet", "label": I18n.tr("Ethernet") },
        { "key": "bluetooth", "label": I18n.tr("Bluetooth") },
        { "key": "hotspot", "label": I18n.tr("Hotspot") },
        { "key": "vpn", "label": I18n.tr("VPN") },
        { "key": "dns", "label": I18n.tr("DNS") },
        { "key": "phone", "label": I18n.tr("Phone") }
    ]
    // subtabs that live in their own file, loaded beside the body Loader
    readonly property var fileTabs: ({
        "ethernet": "ConnectionsEthernetTab.qml",
        "vpn": "ConnectionsVpnTab.qml",
        "dns": "ConnectionsDnsTab.qml",
        "phone": "PhoneConnectionTab.qml"
    })
    readonly property bool onFileTab: pg.fileTabs[pg.sub] !== undefined
    readonly property int tabW: 120
    function tabIndex(k) {
        for (var i = 0; i < tabs.length; i++)
            if (tabs[i].key === k)
                return i;
        return 0;
    }

    // Full machine isolation is intentionally outside the Wi-Fi subtab: it
    // blocks every non-loopback path (including Ethernet, VPN, LAN and IPv6).
    // The helper owns the firewall and NetworkManager transition; this page
    // only asks it for a state and renders the result.
    property string killState: "checking"
    property string killError: ""
    property bool killBusy: false
    readonly property bool killActive: killState === "on" || killState === "armed" || killState === "blocked"

    function refreshKillState() {
        if (!killStatus.running)
            killStatus.running = true;
    }

    function toggleKillSwitch() {
        killBusy = true;
        killError = "";
        killSetProc.target = killState === "off" ? "on" : "off";
        killSetProc.running = true;
    }

    Process {
        id: killStatus
        command: ["ryoku-host", "network", "kill", "status"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                var state = this.text.trim();
                if (state === "on" || state === "off" || state === "armed" || state === "blocked") {
                    pg.killState = state;
                    pg.killError = "";
                } else {
                    pg.killState = "unknown";
                    pg.killError = I18n.tr("Could not read the network kill switch.");
                }
        }
        }
        stderr: StdioCollector {}
        onExited: function(exitCode) {
            if (exitCode !== 0) {
                pg.killState = "unknown";
                pg.killError = I18n.tr("Could not read the network kill switch.");
            }
        }
    }

    Process {
        id: killSetProc
        property string target: ""
        command: ["ryoku-host", "network", "kill", target]
        stderr: StdioCollector {}
        onExited: function(exitCode) {
            pg.killBusy = false;
            if (exitCode !== 0)
                pg.killError = I18n.tr("Could not change the network kill switch.");
            pg.refreshKillState();
        }
    }

    // ── shared drawn chrome (monochrome, ink) ──────────────────────────────

    // signal strength as four ascending ink bars. data drawn in ink, sharp
    // pixels: the shape is the point (DESIGN section 4). onBone flips the ramp
    // for a bar sitting on an inverted (connected) row.
    component SignalBars: Item {
        id: sbars
        property int strength: 0
        property bool onBone: false
        implicitWidth: 21
        implicitHeight: 16
        readonly property int filled: Math.max(0, Math.min(4, Math.ceil(strength / 25)))
        readonly property color lit: onBone ? Tokens.inkOnBone : Tokens.ink
        readonly property color dim: onBone ? Tokens.lineOnBone : Tokens.inkFaint
        Repeater {
            model: 4
            Rectangle {
                required property int index
                x: index * 6
                width: 3
                height: 4 + index * 4
                y: sbars.height - height
                radius: Tokens.radius
                antialiasing: false
                color: sbars.filled > index ? sbars.lit : sbars.dim
            }
        }
    }

    // a padlock silhouette for secured networks. redundant with the "Secured"
    // word, kept because it is a listed surface; drawn, not a font glyph.
    component Lock: Item {
        id: lk
        property color tint: Tokens.inkMuted
        implicitWidth: 12
        implicitHeight: 14
        Shape {
            x: 0; y: 0
            width: 12; height: 8
            preferredRendererType: Shape.CurveRenderer
            antialiasing: true
            ShapePath {
                strokeColor: lk.tint
                strokeWidth: 1.4
                fillColor: "transparent"
                capStyle: ShapePath.RoundCap
                joinStyle: ShapePath.RoundJoin
                PathSvg { path: "M2.4 8 V4.2 A3.6 3.6 0 0 1 9.6 4.2 V8" }
            }
        }
        Rectangle {
            x: 0.5; y: 6
            width: 11; height: 8
            radius: 1
            color: lk.tint
        }
    }

    // the Bluetooth rune, verbatim path from the old tab, stroked in ink.
    component BtRune: Item {
        id: bru
        property color tint: Tokens.inkMuted
        property real span: 24
        implicitWidth: bru.span
        implicitHeight: bru.span
        Shape {
            anchors.centerIn: parent
            width: 24; height: 24
            scale: bru.span / 24
            transformOrigin: Item.Center
            preferredRendererType: Shape.CurveRenderer
            antialiasing: true
            ShapePath {
                strokeColor: bru.tint
                strokeWidth: 1.7
                fillColor: "transparent"
                capStyle: ShapePath.RoundCap
                joinStyle: ShapePath.RoundJoin
                PathSvg { path: "M6.5 6.5l11 11L12 23V1l5.5 5.5L6.5 17.5" }
            }
        }
    }

    // wifi glyph for the hotspot card: two arcs over a dot, drawn in ink.
    component WifiGlyph: Item {
        id: wg
        property color tint: Tokens.inkMuted
        implicitWidth: 22
        implicitHeight: 22
        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            antialiasing: true
            ShapePath {
                strokeColor: wg.tint
                strokeWidth: 1.6
                fillColor: "transparent"
                capStyle: ShapePath.RoundCap
                PathSvg { path: "M3 9 Q11 1 19 9" }
            }
            ShapePath {
                strokeColor: wg.tint
                strokeWidth: 1.6
                fillColor: "transparent"
                capStyle: ShapePath.RoundCap
                PathSvg { path: "M6 12 Q11 6.5 16 12" }
            }
        }
        Rectangle {
            width: 3; height: 3
            radius: 1.5
            color: wg.tint
            anchors.horizontalCenter: parent.horizontalCenter
            y: 15
        }
    }

    // the one perpetual animation allowed on an app surface (DESIGN section 5):
    // a 600/600 heartbeat, 1.0 <-> 0.3. used for the pairing pulse.
    component PulseDot: Rectangle {
        id: pd
        property bool on: false
        implicitWidth: 8
        implicitHeight: 8
        radius: 4
        color: Tokens.ink
        visible: on
        SequentialAnimation on opacity {
            running: pd.on
            loops: Animation.Infinite
            NumberAnimation { from: 1; to: 0.3; duration: 600; easing.type: Easing.InOutSine }
            NumberAnimation { from: 0.3; to: 1; duration: 600; easing.type: Easing.InOutSine }
        }
    }

    // a small tappable pill (Pair / Disconnect / Show / Hide). 22 tall so it
    // sits inside a device tile; a shorter sibling of Ryoku.Ui Btn.
    component MiniPill: Rectangle {
        id: mp
        property string text: ""
        property bool armed: true
        property bool onBone: false
        signal act()
        implicitHeight: 22
        implicitWidth: mpLab.implicitWidth + 18
        radius: Tokens.radius
        opacity: armed ? 1 : 0.3
        color: onBone
            ? (mph.hovered && armed ? Tokens.inkOnBoneDim : Tokens.inkOnBone)
            : (mph.hovered && armed ? Tokens.tint10 : "transparent")
        border.width: Tokens.border
        border.color: onBone ? Tokens.inkOnBone : (mph.hovered && armed ? Tokens.lineStrong : Tokens.line)
        Behavior on color { ColorAnimation { duration: Tokens.snap } }
        Behavior on border.color { ColorAnimation { duration: Tokens.snap } }
        Text {
            id: mpLab
            anchors.centerIn: parent
            text: mp.text
            color: mp.onBone ? Tokens.bone : Tokens.ink
            font.family: Tokens.ui
            font.pixelSize: Tokens.fMicro
            font.weight: Font.Medium
        }
        HoverHandler { id: mph; enabled: mp.armed; cursorShape: Qt.PointingHandCursor }
        TapHandler { enabled: mp.armed; onTapped: mp.act() }
    }

    // an error is inverted text and the word (DESIGN section 1): a small bone
    // chip carrying the failure, no red. used for connect/pair failures.
    component ErrChip: Rectangle {
        id: ec
        property string text: ""
        implicitHeight: 22
        implicitWidth: ecLab.implicitWidth + 16
        radius: Tokens.radius
        color: Tokens.bone
        Text {
            id: ecLab
            anchors.centerIn: parent
            text: ec.text
            color: Tokens.inkOnBone
            font.family: Tokens.ui
            font.pixelSize: Tokens.fSmall
            font.weight: Font.Medium
        }
    }

    // an editable label/value row (hotspot credentials). driven entirely by
    // properties + signals so it can live at file scope; the body wires it to
    // hsEdit/hsDraft. tap the value to drop in the inline editor; Enter commits,
    // Esc (or focus loss) cancels.
    component CredRow: Item {
        id: cr
        property string field: ""
        property string label: ""
        property string value: ""
        property string placeholder: ""
        property bool secret: false
        property bool editing: false
        property string draft: ""
        property bool reveal: false
        readonly property bool tooShort: cr.field === "pw" && cr.editing
            && cr.draft.length > 0 && cr.draft.length < 8
        signal beginEdit()
        signal draftEdited(string v)
        signal commit()
        signal cancel()

        width: parent ? parent.width : 0
        implicitHeight: 44 + (cr.tooShort ? hint.implicitHeight + 4 : 0)

        onEditingChanged: if (cr.editing) Qt.callLater(crInput.forceActiveFocus)

        Rectangle {
            id: crField
            anchors { left: parent.left; right: parent.right; top: parent.top }
            height: 44
            radius: Tokens.radius
            color: cr.editing ? Tokens.tint5 : "transparent"
            border.width: cr.editing ? 2 : Tokens.border
            border.color: cr.editing ? Tokens.ink : Tokens.line
            Behavior on color { ColorAnimation { duration: Tokens.snap } }
            Behavior on border.color { ColorAnimation { duration: Tokens.snap } }

            Text {
                id: crLabel
                anchors.left: parent.left
                anchors.leftMargin: Tokens.s4
                anchors.verticalCenter: parent.verticalCenter
                text: I18n.tr(cr.label)
                color: Tokens.inkMuted
                font.family: Tokens.ui
                font.pixelSize: Tokens.fSmall
                font.weight: Font.Medium
            }

            // read-only value + tap-to-edit affordance.
            Item {
                visible: !cr.editing
                anchors.left: crLabel.right
                anchors.right: (cr.secret && cr.value.length > 0) ? revealPill.left : parent.right
                anchors.rightMargin: Tokens.s4
                anchors.verticalCenter: parent.verticalCenter
                height: parent.height

                Text {
                    id: crValue
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    readonly property bool hidden: cr.secret && !cr.reveal && cr.value.length > 0
                    text: cr.value.length === 0
                        ? (cr.placeholder.length ? cr.placeholder : I18n.tr("tap to set"))
                        : (hidden ? "\u2022".repeat(Math.max(cr.value.length, 8)) : cr.value)
                    color: cr.value.length === 0 ? Tokens.inkFaint : Tokens.ink
                    font.family: cr.secret ? Tokens.mono : Tokens.ui
                    font.pixelSize: Tokens.fSmall
                    font.weight: Font.Medium
                    font.features: ({ "tnum": 1 })
                    elide: Text.ElideLeft
                    maximumLineCount: 1
                }

                HoverHandler { cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: cr.beginEdit() }
            }

            MiniPill {
                id: revealPill
                visible: cr.secret && !cr.editing && cr.value.length > 0
                anchors.right: parent.right
                anchors.rightMargin: Tokens.s3
                anchors.verticalCenter: parent.verticalCenter
                text: cr.reveal ? I18n.tr("Hide") : I18n.tr("Show")
                onAct: cr.reveal = !cr.reveal
            }

            TextInput {
                id: crInput
                visible: cr.editing
                anchors.left: crLabel.right
                anchors.leftMargin: Tokens.s3
                anchors.right: parent.right
                anchors.rightMargin: Tokens.s3
                anchors.verticalCenter: parent.verticalCenter
                horizontalAlignment: TextInput.AlignRight
                color: Tokens.ink
                font.family: cr.secret ? Tokens.mono : Tokens.ui
                font.pixelSize: Tokens.fSmall
                font.weight: Font.Medium
                selectByMouse: true
                selectionColor: Tokens.ink
                selectedTextColor: Tokens.inkOnBone
                text: cr.editing ? cr.draft : ""
                onTextEdited: cr.draftEdited(text)
                onAccepted: cr.commit()
                onActiveFocusChanged: if (!activeFocus && cr.editing) cr.commit()
                Keys.onEscapePressed: (event) => { cr.cancel(); event.accepted = true; }

                Text {
                    anchors.fill: parent
                    visible: crInput.text === ""
                    text: cr.field === "pw" ? I18n.tr("8+ characters") : I18n.tr("Network name")
                    color: Tokens.inkMuted
                    font: crInput.font
                    horizontalAlignment: Text.AlignRight
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }

        // live guidance while typing a too-short password. muted, not a
        // failure: real rejection happens silently in commitHotspotEdit.
        Text {
            id: hint
            visible: cr.tooShort
            anchors.left: parent.left
            anchors.leftMargin: Tokens.s4
            anchors.top: crField.bottom
            anchors.topMargin: 4
            text: I18n.tr("WPA2 needs at least 8 characters")
            color: Tokens.inkMuted
            font.family: Tokens.ui
            font.pixelSize: Tokens.fSmall
            font.weight: Font.Medium
        }
    }

    // ── Wi-Fi subtab ────────────────────────────────────────────────────────

    // master on/off, rescan (spins ~10s), live list sorted by signal. security
    // + known-profile ground truth come from nmcli; the Quickshell service
    // doesn't expose them. tap a secured unknown net -> inline password row that
    // joins through the shell daemon (nmcli when it cannot), secret piped
    // through stdin so it never lands in /proc/<pid>/cmdline.
    component WifiBody: Item {
        id: wifi

        property bool active: true

        readonly property var devices: (typeof Networking !== "undefined" && Networking && Networking.devices) ? Networking.devices.values : []
        readonly property var wifiDev: devices.find(function(d) { return d && d.type === DeviceType.Wifi }) || null
        readonly property bool wifiOn: (typeof Networking !== "undefined" && Networking) ? Networking.wifiEnabled : false
        readonly property var nets: (wifiDev && wifiDev.networks) ? wifiDev.networks.values : []
        // saved networks in range lead (the connected one first), then the
        // rest, each by signal; the list heads each group
        function isSaved(n) { return !!n && (n.connected === true || wifi.knownProfiles[n.name] === true); }
        readonly property var netsSorted: nets
            .slice()
            .filter(function(n) { return n && n.name && n.name.length > 0; })
            .sort(function(a, b) {
                if ((a.connected === true) !== (b.connected === true))
                    return a.connected === true ? -1 : 1;
                var sa = wifi.isSaved(a), sb = wifi.isSaved(b);
                if (sa !== sb)
                    return sa ? -1 : 1;
                return ((b ? b.signalStrength : 0) || 0) - ((a ? a.signalStrength : 0) || 0);
            })
        readonly property int savedCount: netsSorted.filter(function(n) { return wifi.isSaved(n); }).length

        property var securityMap: ({})
        // saved profiles keyed by the SSID they join, never by profile name:
        // NetworkManager names a second profile for an SSID `<ssid> 1`, and an
        // imported one can carry any name. profileUuids lists each SSID's
        // profiles, most recently used first.
        property var knownProfiles: ({})
        property var profileUuids: ({})
        function uuidsFor(ssid) { return wifi.profileUuids[ssid] || []; }

        // per-saved-network autoconnect, read live from `nmcli`. a profile
        // rejoins on its own by default; turning it off stops the machine
        // associating with that SSID unprompted. autoBusy gates the toggle
        // while nmcli rewrites the profile.
        property var autoconnectMap: ({})
        property bool autoBusy: false

        // dual and tri-band SSIDs expose one BSSID per band. bandMap keys each
        // SSID to its per-band BSSIDs so a join can pin a band; selectedBands is
        // the user's per-SSID pick ("" means let NM choose, which favours the
        // 2.4 GHz AP at any range).
        property var bandMap: ({})
        // Details shows each row's access points, so two networks sharing a
        // name can be told apart; off by default, not persisted
        property bool showDetails: false
        function detailsLine(ssid) {
            var entries = wifi.bandMap[ssid] || [];
            var parts = [];
            for (var i = 0; i < entries.length; i++) {
                if (!entries[i].bssid.length)
                    continue;
                parts.push(wifi.bandLabel(entries[i].band) + " " + entries[i].bssid
                    + (entries[i].active ? " " + I18n.tr("(connected)") : ""));
            }
            return parts.join("  \u00b7  ");
        }
        property var selectedBands: ({})

        property string expandedSsid: ""
        property bool connecting: false
        property bool connectFailed: false
        property bool scanning: false

        // NetworkManager's Wi-Fi backend, read and applied through the host seam.
        // iwd is the default; wpa_supplicant is the escape hatch for WPA3 / phone
        // hotspots iwd stumbles on. backendBusy gates the segment while the host
        // seam rewrites the NM drop-in and restarts the service.
        property string wifiBackend: "iwd"
        property bool backendBusy: false

        // NM rescan = fresh model array, so the delegate tears down mid-typing.
        // draft lives on the body; the password field re-fills from it on rebuild.
        property string pwDraft: ""
        property string pendingPw: ""
        property string attemptSsid: ""
        property string attemptBand: ""
        property bool attemptWasKnown: false
        property bool attemptAutoOff: false
        // a password join runs through the daemon, which removes the profile
        // its rejected join created; a join it could not run falls back to
        // nmcli below, whose failure the page cleans up as before
        property bool attemptViaDaemon: false
        // the passphrase, held only while a daemon join runs, for the nmcli
        // fallback when the daemon does not answer
        property string fallbackPw: ""

        property string authFailedSsid: ""
        property string forgetArmed: ""
        // the saved network whose IP settings are open (ConnectionsIpEditor)
        property string ipOpen: ""
        property bool forgetBusy: false

        function isSecured(ssid) {
            var sec = wifi.securityMap[ssid];
            return sec !== undefined && sec !== "" && sec !== "--";
        }

        // bumped after a failed attempt so an open field empties instead of
        // keeping the rejected text for the next try to be typed onto
        property int pwEpoch: 0
        function refresh() {
            secProc.running = true;
            profProc.running = true;
        }

        // flip autoconnect on every profile of the SSID, since any one left on
        // rejoins it. refresh re-reads the map on completion.
        function setAutoconnect(ssid, enabled) {
            var uuids = wifi.uuidsFor(ssid);
            if (wifi.autoBusy || !uuids.length)
                return;
            wifi.autoBusy = true;
            autoProc.command = ["sh", "-c",
                'v=$1; shift; r=0; for u; do nmcli connection modify uuid "$u" connection.autoconnect "$v" || r=1; done; exit $r',
                "sh", enabled ? "yes" : "no"].concat(uuids);
            autoProc.running = true;
        }

        // Flip the NM backend. The host seam validates the choice, escalates once,
        // and delegates to the packaged helper.
        function setBackend(choice) {
            if (wifi.backendBusy || choice === wifi.wifiBackend)
                return;
            wifi.backendBusy = true;
            backendSetProc.command = ["ryoku-host", "network", "wifi-backend", "set", choice];
            backendSetProc.running = true;
        }

        // split one `nmcli -t` line into its fields at unescaped colons, undoing
        // nmcli's escaping (`\:` for a colon inside a field, `\\` for a
        // backslash). a BSSID carries five colons, so the old last-colon split
        // could never reach the fields past it.
        function terseFields(line) {
            var fields = [];
            var cur = "";
            for (var i = 0; i < line.length; i++) {
                var c = line[i];
                if (c === "\\" && i + 1 < line.length && (line[i + 1] === ":" || line[i + 1] === "\\")) {
                    cur += line[i + 1];
                    i++;
                } else if (c === ":") {
                    fields.push(cur);
                    cur = "";
                } else {
                    cur += c;
                }
            }
            fields.push(cur);
            return fields;
        }

        // 2.4 / 5 / 6 GHz bucket for a channel frequency in MHz (contract A);
        // "" when the frequency is unknown.
        function bandForFreq(mhz) {
            if (!mhz || mhz <= 0)
                return "";
            if (mhz < 2500)
                return "2.4";
            if (mhz < 5925)
                return "5";
            return "6";
        }

        function bandLabel(b) {
            if (b === "6")
                return I18n.tr("6 GHz");
            if (b === "5")
                return I18n.tr("5 GHz");
            return I18n.tr("2.4 GHz");
        }

        // NetworkManager's band value for the band the user picked for this
        // SSID: "a" (5 GHz), "bg" (2.4 GHz), or "" (none picked, or 6 GHz,
        // which NM's band property cannot express). The join pins the profile
        // to the band, never to one AP's BSSID: a BSSID pin stops the client
        // roaming between the access points of the same network, which on a
        // multi-AP 5 GHz network reads as a connect/disconnect loop.
        function pickedBand(ssid) {
            var band = wifi.selectedBands[ssid];
            if (!band)
                return "";
            if (band === "5")
                return "a";
            if (band === "2.4")
                return "bg";
            return "";
        }

        // record the per-SSID band pick as a fresh object so the chips re-read it.
        function selectBand(ssid, band) {
            var next = {};
            for (var k in wifi.selectedBands)
                next[k] = wifi.selectedBands[k];
            next[ssid] = band;
            wifi.selectedBands = next;
        }

        // row click: connected -> disconnect, known or open -> connect, else
        // expand the inline password row.
        function activateNetwork(net) {
            if (!net)
                return;
            var ssid = net.name || "";
            if (wifi.expandedSsid === ssid) {
                wifi.expandedSsid = "";
                return;
            }
            if (net.connected) {
                if (typeof net.disconnect === "function")
                    net.disconnect();
                return;
            }
            var secKnown = wifi.securityMap[ssid] !== undefined;
            if (wifi.knownProfiles[ssid] === true || (secKnown && !wifi.isSecured(ssid))) {
                wifi.expandedSsid = "";
                wifi.connectFailed = false;
                wifi.authFailedSsid = "";
                if (wifi.pickedBand(ssid).length) {
                    wifi.connectBand(ssid);
                    return;
                }
                wifi.connectSaved(ssid);
                return;
            }
            wifi.connectFailed = false;
            wifi.pwDraft = "";
            wifi.expandedSsid = ssid;
        }

        // a saved secured network whose stored secret was refused: reopen its
        // password row, emptied so the next try is not typed onto the old text
        function savedJoinRejected(ssid) {
            if (!ssid.length)
                return;
            wifi.connectFailed = true;
            wifi.authFailedSsid = ssid;
            wifi.pwDraft = "";
            wifi.pwEpoch++;
            wifi.expandedSsid = ssid;
        }

        function requestForget(ssid) {
            if (wifi.forgetBusy || !ssid.length)
                return;
            if (wifi.forgetArmed !== ssid) {
                wifi.forgetArmed = ssid;
                forgetReset.restart();
                return;
            }
            var uuids = wifi.uuidsFor(ssid);
            forgetReset.stop();
            if (!uuids.length) {
                wifi.forgetArmed = "";
                return;
            }
            wifi.forgetBusy = true;
            var cmd = ["nmcli", "connection", "delete"];
            for (var i = 0; i < uuids.length; i++)
                cmd.push("uuid", uuids[i]);
            forgetProc.command = cmd;
            forgetProc.running = true;
        }

        // Password through stdin: /proc/<pid>/cmdline is world-readable for the
        // whole attempt, so it MUST NOT be in argv, and never through `nmcli
        // connection edit`, which keeps every line it reads in
        // ~/.cache/nmcli-history. The join goes through the shell daemon, which
        // owns Wi-Fi joins: with no secret agent a rejected password fails as
        // soon as NetworkManager drops it, where `nmcli --ask` waited out its
        // 90-second timeout. The SSID's saved profiles are replaced once the
        // daemon's socket answers, and a failed join cleans up like a first
        // join.
        function connectWithPassword(ssid, pw) {
            if (connProc.running || !pw.length)
                return;
            wifi.connecting = true;
            wifi.connectFailed = false;
            wifi.attemptSsid = ssid;
            wifi.attemptBand = wifi.pickedBand(ssid);
            wifi.attemptWasKnown = false;
            wifi.attemptViaDaemon = true;
            wifi.attemptAutoOff = wifi.knownProfiles[ssid] === true && wifi.autoconnectMap[ssid] === false;
            wifi.pendingPw = pw;
            wifi.fallbackPw = pw;
            connProc.command = ["ryoku-hub", "wifi", "connect", ssid];
            connProc.stdinEnabled = true;
            connProc.running = true;
        }

        // the join without the daemon, as the page ran it before: it works, but
        // a rejected password waits out nmcli's 90-second --ask timeout
        function joinWithNmcli() {
            wifi.attemptViaDaemon = false;
            wifi.pendingPw = wifi.fallbackPw;
            wifi.fallbackPw = "";
            connProc.command = ["sh", "-c",
                's=$1; shift; for u; do nmcli connection delete uuid "$u" </dev/null >/dev/null 2>&1; done; exec nmcli --ask dev wifi connect "$s"',
                "sh", wifi.attemptSsid].concat(wifi.uuidsFor(wifi.attemptSsid));
            connProc.stdinEnabled = true;
            connProc.running = true;
        }

        // a saved network joins through nmcli too, so a refused stored secret
        // comes back as connProc's exit code; Quickshell's connectionFailed is
        // not always emitted for it
        function connectSaved(ssid) {
            if (connProc.running)
                return;
            wifi.connecting = true;
            wifi.connectFailed = false;
            wifi.attemptSsid = ssid;
            wifi.attemptBand = "";
            wifi.attemptWasKnown = wifi.knownProfiles[ssid] === true;
            wifi.attemptViaDaemon = false;
            wifi.attemptAutoOff = false;
            wifi.pendingPw = "";
            connProc.command = wifi.attemptWasKnown
                ? ["nmcli", "connection", "up", "uuid", wifi.uuidsFor(ssid)[0]]
                : ["nmcli", "dev", "wifi", "connect", ssid];
            connProc.stdinEnabled = true;
            connProc.running = true;
        }

        // known/open join pinned to a band. The profile is locked to the band
        // after the join (nmcli's connect target takes no settings), never to
        // one AP's BSSID, so the client still roams across the band.
        function connectBand(ssid) {
            if (connProc.running)
                return;
            wifi.connecting = true;
            wifi.connectFailed = false;
            wifi.attemptSsid = ssid;
            wifi.attemptBand = wifi.pickedBand(ssid);
            wifi.attemptWasKnown = wifi.knownProfiles[ssid] === true;
            wifi.attemptViaDaemon = false;
            wifi.attemptAutoOff = false;
            wifi.pendingPw = "";
            connProc.command = ["nmcli", "dev", "wifi", "connect", ssid];
            connProc.stdinEnabled = true;
            connProc.running = true;
        }

        // reload pulse. forces an nmcli rescan and spins the button up to 10s.
        function startScan() {
            if (!wifi.wifiOn)
                return;
            wifi.scanning = true;
            rescanProc.running = true;
            scanTimer.restart();
        }

        function stopScan() {
            wifi.scanning = false;
            scanTimer.stop();
        }

        Component.onCompleted: { wifi.refresh(); backendGetProc.running = true; }

        onWifiOnChanged: if (!wifi.wifiOn) wifi.stopScan()

        Binding {
            target: wifi.wifiDev
            property: "scannerEnabled"
            value: wifi.active && wifi.wifiOn
            when: wifi.wifiDev !== null
        }

        Timer {
            id: scanTimer
            interval: 10000
            onTriggered: wifi.stopScan()
        }

        Process {
            id: rescanProc
            command: ["nmcli", "dev", "wifi", "rescan"]
            onExited: wifi.refresh()
        }

        Process {
            id: secProc
            command: ["nmcli", "-t", "-f", "SSID,SECURITY,FREQ,BSSID,SIGNAL,ACTIVE", "dev", "wifi", "list"]
            stdout: StdioCollector {
                onStreamFinished: {
                    var secs = {};
                    var bands = {};
                    var lines = this.text.split("\n");
                    for (var i = 0; i < lines.length; i++) {
                        if (!lines[i].length)
                            continue;
                        var f = wifi.terseFields(lines[i]);
                        if (f.length < 3 || !f[0].length)
                            continue;
                        secs[f[0]] = f[1];
                        var mhz = parseInt(f[2], 10);
                        var band = wifi.bandForFreq(mhz);
                        if (!band.length)
                            continue;
                        // one entry per band: the connected AP, else the strongest,
                        // whose BSSID the Details view shows
                        var ap = { band: band, freq: mhz, bssid: f[3] || "",
                            signal: parseInt(f[4], 10) || 0, active: f[5] === "yes" };
                        var entries = bands[f[0]] || [];
                        var at = -1;
                        for (var j = 0; j < entries.length; j++)
                            if (entries[j].band === band) {
                                at = j;
                                break;
                            }
                        if (at < 0)
                            entries.push(ap);
                        else if (ap.active || (!entries[at].active && ap.signal > entries[at].signal))
                            entries[at] = ap;
                        bands[f[0]] = entries;
                    }
                    for (var s in bands)
                        bands[s].sort(function(a, b) { return a.freq - b.freq; });
                    wifi.securityMap = secs;
                    wifi.bandMap = bands;
                }
            }
        }

        Process {
            id: profProc
            // the profile list has no SSID column, so each Wi-Fi profile is read
            // on its own; -g prints one field per line, the SSID last and
            // unescaped so it is taken whole, then one tab-separated row each.
            // A hotspot (mode ap) is not a saved network, even when it shares
            // a scanned network's name.
            command: ["sh", "-c",
                'nmcli -t -f UUID,TYPE connection show | while IFS=: read -r u t; do '
                + '[ "$t" = 802-11-wireless ] || continue; '
                + 'nmcli -e no -g connection.autoconnect,connection.timestamp,802-11-wireless.mode,802-11-wireless.ssid connection show uuid "$u" '
                + '| { read -r a; read -r ts; read -r m; IFS= read -r s; [ "$m" = ap ] || printf "%s\\t%s\\t%s\\t%s\\n" "$u" "$a" "$ts" "$s"; }; done']
            stdout: StdioCollector {
                onStreamFinished: {
                    var rows = [];
                    var lines = this.text.split("\n");
                    for (var i = 0; i < lines.length; i++) {
                        var f = lines[i].split("\t");
                        if (f.length >= 4 && f[0].length && f.slice(3).join("\t").length)
                            rows.push({ uuid: f[0], auto: f[1] === "yes", ts: parseInt(f[2], 10) || 0, ssid: f.slice(3).join("\t") });
                    }
                    rows.sort(function(a, b) { return b.ts - a.ts; });
                    var set = {};
                    var auto = {};
                    var uuids = {};
                    for (var j = 0; j < rows.length; j++) {
                        var r = rows[j];
                        set[r.ssid] = true;
                        auto[r.ssid] = auto[r.ssid] === true || r.auto;
                        (uuids[r.ssid] = uuids[r.ssid] || []).push(r.uuid);
                    }
                    wifi.knownProfiles = set;
                    wifi.autoconnectMap = auto;
                    wifi.profileUuids = uuids;
                }
            }
        }

        Process {
            id: connProc
            stdinEnabled: true
            stdout: StdioCollector {}
            stderr: StdioCollector { id: connErr }
            // stdin closes after the password: on a wrong one NetworkManager asks
            // nmcli's --ask agent for another, and with stdin left open nmcli
            // waited there for its 90-second timeout instead of failing
            onStarted: {
                write(wifi.pendingPw + "\n");
                wifi.pendingPw = "";
                stdinEnabled = false;
            }
            onExited: function(exitCode) {
                // ryoku-hub exits 3 when the daemon did not run the join (it never
                // answered, or answered with anything but a rejected password),
                // so the join falls back to nmcli
                if (wifi.attemptViaDaemon && exitCode === 3 && wifi.fallbackPw.length) {
                    Qt.callLater(wifi.joinWithNmcli);
                    return;
                }
                wifi.fallbackPw = "";
                wifi.connecting = false;
                if (exitCode === 0) {
                    wifi.expandedSsid = "";
                    wifi.pwDraft = "";
                    wifi.connectFailed = false;
                    wifi.authFailedSsid = "";
                    var mods = [];
                    if (wifi.attemptBand.length)
                        mods.push("802-11-wireless.band", wifi.attemptBand);
                    if (wifi.attemptAutoOff)
                        mods.push("connection.autoconnect", "no");
                    if (mods.length && wifi.attemptSsid.length) {
                        bandProc.command = ["sh", "-c",
                            's=$1; shift; for u in $(nmcli -t -f UUID,TYPE connection show --active | awk -F: \'$2 == "802-11-wireless" { print $1 }\'); do '
                            + '[ "$(nmcli -e no -g 802-11-wireless.ssid connection show uuid "$u")" = "$s" ] && exec nmcli connection modify uuid "$u" "$@"; done',
                            "sh", wifi.attemptSsid].concat(mods);
                        bandProc.running = true;
                        return;
                    }
                    wifi.refresh();
                } else {
                    wifi.connectFailed = true;
                    wifi.pwDraft = "";
                    wifi.pwEpoch++;
                    if (wifi.attemptWasKnown) {
                        if (wifi.isSecured(wifi.attemptSsid) && /secret|supplicant|password/i.test(connErr.text))
                            wifi.savedJoinRejected(wifi.attemptSsid);
                    } else if (wifi.attemptSsid.length && !wifi.attemptViaDaemon) {
                        cleanupProc.command = ["sh", "-c",
                            'nmcli -t -f UUID,TYPE connection show | while IFS=: read -r u t; do '
                            + '[ "$t" = 802-11-wireless ] && [ "$(nmcli -e no -g 802-11-wireless.ssid connection show uuid "$u")" = "$1" ] '
                            + '&& [ "$(nmcli -g 802-11-wireless.mode connection show uuid "$u")" != ap ] '
                            + '&& nmcli connection delete uuid "$u"; done; exit 0',
                            "sh", wifi.attemptSsid];
                        cleanupProc.running = true;
                    }
                }
            }
        }

        Process {
            id: forgetProc
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: {
                if (wifi.expandedSsid === wifi.forgetArmed)
                    wifi.expandedSsid = "";
                if (wifi.authFailedSsid === wifi.forgetArmed)
                    wifi.authFailedSsid = "";
                wifi.forgetArmed = "";
                wifi.forgetBusy = false;
                wifi.refresh();
            }
        }

        Timer {
            id: forgetReset
            interval: 3000
            onTriggered: wifi.forgetArmed = ""
        }

        // a failed `nmcli dev wifi connect` leaves a profile behind, and
        // without deleting it the next click reads the network as known and
        // silently fails forever. Only a join that left no saved profile of
        // the SSID gets here (a password join deletes them first), so every
        // profile of the SSID is the failed one, a hotspot aside; it is matched
        // by SSID because nmcli names it `<ssid> 1` when the name is taken.
        Process {
            id: cleanupProc
            onExited: wifi.refresh()
        }

        // carry the picked band (and an auto-reconnect the user had off) onto
        // the just-joined profile. nmcli's `dev wifi connect` takes no
        // settings, so they ride on the profile after the join. The join may
        // reuse a profile named other than the SSID, so the target is the
        // active Wi-Fi profile for that SSID.
        Process {
            id: bandProc
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: wifi.refresh()
        }

        // apply an autoconnect flip, then re-read the profiles so the toggle
        // reflects the stored state rather than the click.
        Process {
            id: autoProc
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: {
                wifi.autoBusy = false;
                wifi.refresh();
            }
        }

        onNetsChanged: if (wifi.active) secRefresh.restart()

        Timer {
            id: secRefresh
            interval: 1200
            // a network saved or forgotten elsewhere (the bar, nmcli) shows up
            // as a network-list change; re-read the saved profiles with it
            onTriggered: if (wifi.active) { secProc.running = true; profProc.running = true; }
        }

        // Read the current NM Wi-Fi backend through the host seam.
        Process {
            id: backendGetProc
            command: ["ryoku-host", "network", "wifi-backend", "get"]
            stdout: StdioCollector {
                onStreamFinished: {
                    var v = this.text.trim();
                    if (v === "iwd" || v === "wpa_supplicant")
                        wifi.wifiBackend = v;
                }
            }
        }

        // Apply through the host seam. NetworkManager restarts, so on exit
        // re-read state and, once it settles,
        // refresh + rescan so the list repopulates on the new backend.
        Process {
            id: backendSetProc
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: {
                wifi.backendBusy = false;
                backendGetProc.running = true;
                backendSettle.restart();
            }
        }

        Timer {
            id: backendSettle
            interval: 1500
            onTriggered: {
                wifi.refresh();
                wifi.startScan();
            }
        }

        Item {
            id: wifiContent
            anchors.fill: parent

            // header row: "WI-FI" label + hairline + scan button.
            Item {
                id: wifiBar
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                height: 40

                Text {
                    id: wifiSecLabel
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: I18n.tr("WI-FI")
                    color: Tokens.ink
                    font.family: Tokens.ui
                    font.pixelSize: Tokens.fMicro
                    font.weight: Font.Medium
                    font.letterSpacing: Tokens.trackMark
                }

                Rectangle {
                    anchors.left: wifiSecLabel.right
                    anchors.leftMargin: Tokens.s3
                    anchors.right: detailsBtn.visible ? detailsBtn.left : parent.right
                    anchors.rightMargin: detailsBtn.visible ? Tokens.s3 : 0
                    anchors.verticalCenter: parent.verticalCenter
                    height: 1
                    color: Tokens.lineSoft
                }

                Btn {
                    id: detailsBtn
                    anchors.right: scanBtn.left
                    anchors.rightMargin: Tokens.s2
                    anchors.verticalCenter: parent.verticalCenter
                    visible: wifi.wifiOn
                    text: I18n.tr("Details")
                    primary: wifi.showDetails
                    onAct: wifi.showDetails = !wifi.showDetails
                }

                Btn {
                    id: scanBtn
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    visible: wifi.wifiOn
                    text: wifi.scanning ? I18n.tr("Scanning\u2026") : I18n.tr("Scan")
                    armed: !wifi.scanning
                    onAct: wifi.startScan()
                }
            }

            // master on/off. mirrors NM live state; no draft, applies at once.
            Item {
                id: wifiToggleRow
                anchors.top: wifiBar.bottom
                anchors.topMargin: Tokens.s3
                anchors.left: parent.left
                anchors.right: parent.right
                height: 34

                Text {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: I18n.tr("Wi-Fi")
                    color: Tokens.ink
                    font.family: Tokens.ui
                    font.pixelSize: Tokens.fRow
                    font.weight: Font.Medium
                }

                Sw {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    on: wifi.wifiOn
                    onToggled: (v) => {
                        if (typeof Networking !== "undefined" && Networking)
                            Networking.wifiEnabled = v;
                    }
                }
            }

            Rectangle {
                id: wifiDivider
                anchors.top: wifiToggleRow.bottom
                anchors.topMargin: Tokens.s2
                anchors.left: parent.left
                anchors.right: parent.right
                height: 1
                color: Tokens.lineSoft
            }

            // empty states.
            Text {
                anchors.top: wifiDivider.bottom
                anchors.topMargin: Tokens.s6
                anchors.horizontalCenter: parent.horizontalCenter
                visible: !wifi.wifiOn
                text: I18n.tr("Wi-Fi is off.")
                color: Tokens.inkMuted
                font.family: Tokens.ui
                font.pixelSize: Tokens.fSmall
                font.weight: Font.Medium
            }

            Text {
                anchors.top: wifiDivider.bottom
                anchors.topMargin: Tokens.s6
                anchors.horizontalCenter: parent.horizontalCenter
                visible: wifi.wifiOn && wifi.netsSorted.length === 0
                text: I18n.tr("Searching networks\u2026")
                color: Tokens.inkMuted
                font.family: Tokens.ui
                font.pixelSize: Tokens.fSmall
                font.weight: Font.Medium
            }

            // live network list.
            Flickable {
                id: netFlick
                anchors.top: wifiDivider.bottom
                anchors.topMargin: Tokens.s2
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: backendRow.top
                anchors.bottomMargin: Tokens.s2
                visible: wifi.wifiOn && wifi.netsSorted.length > 0
                contentWidth: width
                contentHeight: netCol.implicitHeight + 16
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.vertical: ScrollRail { policy: ScrollBar.AsNeeded }
                WheelScroll { }

                Column {
                    id: netCol
                    width: netFlick.width - Tokens.s3
                    topPadding: 2
                    spacing: 4

                    Repeater {
                        model: wifi.netsSorted

                        delegate: Column {
                            id: netItem
                            required property var modelData
                            required property int index

                            readonly property string ssid: (modelData && modelData.name) ? modelData.name : ""
                            readonly property bool isActive: modelData ? modelData.connected === true : false
                            readonly property bool secured: wifi.isSecured(ssid)
                            readonly property bool known: wifi.knownProfiles[ssid] === true
                            readonly property bool expanded: ssid.length > 0 && wifi.expandedSsid === ssid
                            // Quickshell reports signalStrength as a 0..1 ratio;
                            // the bars and the % readout speak 0..100.
                            readonly property int strength: modelData ? Math.round((modelData.signalStrength || 0) * 100) : 0

                            width: netCol.width
                            spacing: 4

                            function syncPwField() {
                                pwField.text = wifi.pwDraft;
                                pwField.cursorPosition = pwField.text.length;
                                pwField.forceActiveFocus();
                            }

                            onExpandedChanged: if (expanded) Qt.callLater(syncPwField)
                            Connections {
                                target: wifi
                                function onPwEpochChanged() { if (netItem.expanded) netItem.syncPwField(); }
                            }
                            Component.onCompleted: if (expanded) Qt.callLater(syncPwField)

                            Text {
                                readonly property bool firstSaved: netItem.index === 0 && wifi.savedCount > 0
                                readonly property bool firstOther: netItem.index === wifi.savedCount
                                visible: firstSaved || firstOther
                                width: parent.width
                                topPadding: firstOther && wifi.savedCount > 0 ? Tokens.s4 : 0
                                bottomPadding: Tokens.s1
                                text: firstSaved ? I18n.tr("SAVED") : (wifi.savedCount > 0 ? I18n.tr("OTHER NETWORKS") : I18n.tr("NETWORKS"))
                                color: Tokens.inkMuted
                                font.family: Tokens.ui
                                font.pixelSize: Tokens.fMicro
                                font.weight: Font.Medium
                                font.letterSpacing: Tokens.trackLabel
                            }

                            // the row. connected = the ON member of the exclusive
                            // Wi-Fi set, so it inverts to bone (DESIGN section 1).
                            Rectangle {
                                id: rowBg
                                readonly property string details: wifi.showDetails ? wifi.detailsLine(netItem.ssid) : ""
                                width: parent.width
                                height: details.length ? 60 : 46
                                radius: Tokens.radius
                                color: netItem.isActive
                                    ? Tokens.bone
                                    : (rowHover.hovered ? Tokens.tint5 : "transparent")
                                Behavior on color { ColorAnimation { duration: Tokens.snap } }

                                HoverHandler { id: rowHover; cursorShape: Qt.PointingHandCursor }
                                TapHandler { onTapped: wifi.activateNetwork(netItem.modelData) }

                                SignalBars {
                                    id: bars
                                    anchors.left: parent.left
                                    anchors.leftMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    strength: netItem.strength
                                    onBone: netItem.isActive
                                }

                                Column {
                                    anchors.left: bars.right
                                    anchors.leftMargin: Tokens.s3
                                    anchors.right: rowRight.left
                                    anchors.rightMargin: Tokens.s3
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: 1

                                    Text {
                                        width: parent.width
                                        text: netItem.ssid
                                        color: netItem.isActive ? Tokens.inkOnBone : Tokens.ink
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fBody
                                        font.weight: netItem.isActive ? Font.DemiBold : Font.Medium
                                        elide: Text.ElideRight
                                    }

                                    Text {
                                        width: parent.width
                                        text: netItem.isActive
                                            ? I18n.tr("Connected")
                                            : (netItem.known
                                                ? (netItem.secured ? I18n.tr("Saved \u00b7 Secured") : I18n.tr("Saved \u00b7 Open"))
                                                : (netItem.secured ? I18n.tr("Secured") : I18n.tr("Open")))
                                        color: netItem.isActive ? Tokens.inkOnBoneDim : Tokens.inkMuted
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fMicro
                                        font.weight: Font.Medium
                                        elide: Text.ElideRight
                                    }

                                    Text {
                                        visible: rowBg.details.length > 0
                                        width: parent.width
                                        text: rowBg.details
                                        color: netItem.isActive ? Tokens.inkOnBoneDim : Tokens.inkMuted
                                        font.family: Tokens.mono
                                        font.pixelSize: Tokens.fMicro
                                        elide: Text.ElideRight
                                    }
                                }

                                Row {
                                    id: rowRight
                                    anchors.right: parent.right
                                    anchors.rightMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: Tokens.s2

                                    Lock {
                                        anchors.verticalCenter: parent.verticalCenter
                                        visible: netItem.secured
                                        tint: netItem.isActive ? Tokens.inkOnBone : Tokens.inkMuted
                                    }

                                    Text {
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: netItem.strength + "%"
                                        color: netItem.isActive ? Tokens.inkOnBoneDim : Tokens.inkMuted
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fMicro
                                        font.weight: Font.Medium
                                        font.features: ({ "tnum": 1 })
                                    }
                                }
                            }

                            // band selector. a dual or tri-band SSID resolves to
                            // one BSSID per band, and NM's SSID join takes the
                            // strongest, which is the 2.4 GHz AP at any range.
                            // picking a band locks the saved profile to that
                            // band, never to one AP, so the client still roams.
                            Item {
                                id: bandRow
                                readonly property var entries: wifi.bandMap[netItem.ssid] || []
                                width: parent.width
                                height: entries.length > 1 ? 30 : 0
                                clip: true
                                visible: height > 0.5

                                Row {
                                    anchors.left: parent.left
                                    anchors.leftMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: Tokens.s2

                                    Repeater {
                                        model: bandRow.entries

                                        delegate: Btn {
                                            required property var modelData
                                            // the row by id, not `parent`: a Repeater delegate has no
                                            // parent yet while it is being created, so anchoring to it
                                            // logged a TypeError for every band chip built.
                                            anchors.verticalCenter: bandRow.verticalCenter
                                            compact: true
                                            text: wifi.bandLabel(modelData.band)
                                            primary: wifi.selectedBands[netItem.ssid] === modelData.band
                                            armed: !wifi.connecting
                                            onAct: wifi.selectBand(netItem.ssid,
                                                wifi.selectedBands[netItem.ssid] === modelData.band ? "" : modelData.band)
                                        }
                                    }
                                }
                            }

                            // autoconnect toggle. a saved profile rejoins on its
                            // own by default; turning it off stops the machine
                            // associating with this SSID unprompted, so a spoofed
                            // AP can no longer pull the device in. saved rows only.
                            Item {
                                id: autoRow
                                readonly property bool on: wifi.autoconnectMap[netItem.ssid] !== false
                                width: parent.width
                                height: netItem.known ? 36 : 0
                                clip: true
                                visible: height > 0.5

                                // the setting lines up under the network name,
                                // Forget under the signal readout on the right
                                Row {
                                    anchors.left: parent.left
                                    anchors.leftMargin: bars.x + bars.width + Tokens.s3
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: Tokens.s2

                                    Text {
                                        height: autoBtn.height
                                        verticalAlignment: Text.AlignVCenter
                                        text: I18n.tr("Auto-reconnect")
                                        color: Tokens.inkMuted
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fMicro
                                        font.weight: Font.Medium
                                    }

                                    Btn {
                                        id: autoBtn
                                        compact: true
                                        text: autoRow.on ? I18n.tr("On") : I18n.tr("Off")
                                        primary: autoRow.on
                                        armed: !wifi.autoBusy
                                        onAct: wifi.setAutoconnect(netItem.ssid, !autoRow.on)
                                    }

                                    Btn {
                                        compact: true
                                        text: I18n.tr("IP settings") + (wifi.ipOpen === netItem.ssid ? " \u25b4" : " \u25be")
                                        primary: wifi.ipOpen === netItem.ssid
                                        onAct: {
                                            if (wifi.ipOpen !== netItem.ssid)
                                                NetworkTopic.ipOpened(wifi.uuidsFor(netItem.ssid)[0] || "");
                                            wifi.ipOpen = wifi.ipOpen === netItem.ssid ? "" : netItem.ssid;
                                        }
                                    }
                                }

                                Btn {
                                    anchors.right: parent.right
                                    anchors.rightMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    compact: true
                                    text: wifi.forgetArmed === netItem.ssid ? I18n.tr("Confirm \u00b7 Forget") : I18n.tr("Forget")
                                    primary: wifi.forgetArmed === netItem.ssid
                                    armed: !wifi.forgetBusy
                                    onAct: wifi.requestForget(netItem.ssid)
                                }
                            }

                            // IPv4 settings of the saved network, under its settings row
                            Item {
                                width: parent.width
                                height: netItem.known && wifi.ipOpen === netItem.ssid && ipEditor.item
                                    ? ipEditor.item.implicitHeight + Tokens.s3 : 0
                                clip: true
                                visible: height > 0.5
                                Loader {
                                    id: ipEditor
                                    x: bars.x + bars.width + Tokens.s3
                                    width: parent.width - x - Tokens.s4
                                    active: netItem.known && wifi.ipOpen === netItem.ssid
                                    source: Qt.resolvedUrl("ConnectionsIpEditor.qml")
                                    onLoaded: item.uuid = Qt.binding(function() { return wifi.uuidsFor(netItem.ssid)[0] || ""; })
                                }
                            }

                            // password row. secured + unknown, or saved with a rejected secret.
                            Item {
                                width: parent.width
                                height: netItem.expanded ? 44 : 0
                                clip: true
                                visible: height > 0.5
                                opacity: netItem.expanded ? 1 : 0
                                Behavior on height { NumberAnimation { duration: Tokens.move; easing.type: Tokens.ease } }
                                Behavior on opacity { NumberAnimation { duration: Tokens.snap } }

                                Rectangle {
                                    id: pwBg
                                    anchors.left: parent.left
                                    anchors.leftMargin: Tokens.s4
                                    anchors.right: pwRight.left
                                    anchors.rightMargin: Tokens.s3
                                    anchors.verticalCenter: parent.verticalCenter
                                    height: 32
                                    radius: Tokens.radius
                                    color: "transparent"
                                    border.width: pwField.activeFocus ? 2 : Tokens.border
                                    border.color: pwField.activeFocus ? Tokens.ink : Tokens.line
                                    Behavior on border.color { ColorAnimation { duration: Tokens.snap } }

                                    TextInput {
                                        id: pwField
                                        anchors.fill: parent
                                        anchors.leftMargin: Tokens.s3
                                        anchors.rightMargin: Tokens.s3
                                        verticalAlignment: TextInput.AlignVCenter
                                        color: Tokens.ink
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fSmall
                                        echoMode: TextInput.Password
                                        selectByMouse: true
                                        selectionColor: Tokens.ink
                                        selectedTextColor: Tokens.inkOnBone
                                        onTextEdited: wifi.pwDraft = text
                                        onAccepted: wifi.connectWithPassword(netItem.ssid, text)

                                        Text {
                                            anchors.fill: parent
                                            visible: pwField.text === ""
                                            text: netItem.known ? I18n.tr("New password") : I18n.tr("Password")
                                            color: Tokens.inkMuted
                                            font: pwField.font
                                            verticalAlignment: Text.AlignVCenter
                                        }
                                    }
                                }

                                Row {
                                    id: pwRight
                                    anchors.right: parent.right
                                    anchors.rightMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: Tokens.s2

                                    IconBtn {
                                        anchors.verticalCenter: parent.verticalCenter
                                        glyph: "\u00d7"
                                        onAct: wifi.expandedSsid = ""
                                    }

                                    Text {
                                        anchors.verticalCenter: parent.verticalCenter
                                        visible: wifi.connecting
                                        text: I18n.tr("Connecting\u2026")
                                        color: Tokens.inkMuted
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fMicro
                                        font.weight: Font.Medium
                                    }

                                    Btn {
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: I18n.tr("Connect")
                                        primary: true
                                        armed: !wifi.connecting && pwField.text.length > 0
                                        onAct: wifi.connectWithPassword(netItem.ssid, pwField.text)
                                    }
                                }
                            }

                            Item {
                                width: parent.width
                                height: (netItem.expanded && wifi.connectFailed) ? 24 : 0
                                clip: true
                                visible: height > 0.5
                                Behavior on height { NumberAnimation { duration: Tokens.move; easing.type: Tokens.ease } }

                                Row {
                                    anchors.left: parent.left
                                    anchors.leftMargin: Tokens.s4
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: Tokens.s3

                                    ErrChip {
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: wifi.authFailedSsid === netItem.ssid
                                            ? I18n.tr("Wrong password, or a different network with the same name?")
                                            : I18n.tr("Connection failed")
                                    }

                                    Text {
                                        anchors.verticalCenter: parent.verticalCenter
                                        visible: netItem.known && wifi.authFailedSsid === netItem.ssid
                                        text: I18n.tr("A new password replaces the saved one.")
                                        color: Tokens.inkMuted
                                        font.family: Tokens.ui
                                        font.pixelSize: Tokens.fMicro
                                        font.weight: Font.Medium
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // advanced: NetworkManager's Wi-Fi backend. an unobtrusive footer
            // beneath the list; the selected engine inverts to bone, the other is
            // tappable. rare enough to sit out of the way, but reachable when a
            // WPA3 AP or phone hotspot won't associate under iwd.
            Item {
                id: backendRow
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 54

                Rectangle {
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: 1
                    color: Tokens.lineSoft
                }

                Column {
                    anchors.left: parent.left
                    anchors.right: backendSeg.left
                    anchors.rightMargin: Tokens.s3
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2

                    Text {
                        text: I18n.tr("Wi-Fi backend")
                        color: Tokens.ink
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fRow
                        font.weight: Font.Medium
                    }

                    Text {
                        width: parent.width
                        text: I18n.tr("Switch to wpa_supplicant if a WPA3 network or Android hotspot won\u2019t connect.")
                        color: Tokens.inkMuted
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fMicro
                        font.weight: Font.Medium
                        wrapMode: Text.WordWrap
                    }
                }

                Row {
                    id: backendSeg
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Tokens.s2

                    Btn {
                        anchors.verticalCenter: parent.verticalCenter
                        compact: true
                        text: I18n.tr("iwd")
                        primary: wifi.wifiBackend === "iwd"
                        armed: !wifi.backendBusy
                        onAct: wifi.setBackend("iwd")
                    }

                    Btn {
                        anchors.verticalCenter: parent.verticalCenter
                        compact: true
                        text: I18n.tr("wpa_supplicant")
                        primary: wifi.wifiBackend === "wpa_supplicant"
                        armed: !wifi.backendBusy
                        onAct: wifi.setBackend("wpa_supplicant")
                    }
                }
            }
        }
    }

    // ── Bluetooth subtab ─────────────────────────────────────────────────────

    // Adapter toggle, scan with 25s auto-stop, and a live device list. Every
    // disconnected row uses the shared pair-trust-connect helper so known and
    // newly discovered devices follow the same BlueZ-safe sequence.
    component BtBody: Item {
        id: bt

        readonly property var adapter: (typeof Bluetooth !== "undefined" && Bluetooth) ? Bluetooth.defaultAdapter : null
        readonly property var devices: (typeof Bluetooth !== "undefined" && Bluetooth && Bluetooth.devices) ? Bluetooth.devices.values : []
        readonly property bool adapterOn: adapter ? adapter.enabled === true : false
        readonly property bool discovering: adapter ? adapter.discovering === true : false
        readonly property bool hasAdapter: adapter !== null
        readonly property bool adapterBlocked: (adapter && typeof BluetoothAdapterState !== "undefined")
            ? adapter.state === BluetoothAdapterState.Blocked : false
        readonly property bool blocked: adapterBlocked || softBlocked || hardBlocked
        property bool softBlocked: false
        property bool hardBlocked: false
        onAdapterChanged: rfkillState.running = true
        readonly property int connectedCount: {
            var n = 0;
            for (var i = 0; i < devices.length; i++)
                if (devices[i] && devices[i].connected)
                    n++;
            return n;
        }

        // BlueZ hands the cache out unordered. connected first, then paired,
        // then named, nameless MACs last; a scan shouldn't churn useful rows.
        readonly property var devicesSorted: devices.slice().sort(function(a, b) {
            function rank(d) {
                if (!d) return 3;
                if (d.connected) return 0;
                if (d.paired) return 1;
                return (d.name && d.name.length) ? 2 : 3;
            }
            var r = rank(a) - rank(b);
            if (r !== 0) return r;
            return String((a && a.name) || "").localeCompare(String((b && b.name) || ""));
        })

        property string pairingAddress: ""
        property string failedAddress: ""
        property string serviceError: ""

        function metaFor(d) {
            if (!d) return "";
            var parts = [];
            if (d.connected) parts.push("connected");
            else if (d.paired) parts.push("paired");
            if (d.state !== undefined && typeof BluetoothDeviceState !== "undefined") {
                var st = BluetoothDeviceState.toString(d.state);
                if (st && st.length > 0 && parts.indexOf(st.toLowerCase()) === -1)
                    parts.push(st.toLowerCase());
            }
            return parts.join(" \u00b7 ");
        }

        function batteryLevel(d) {
            if (!d || d.battery === undefined || d.battery === null) return -1;
            var b = d.battery;
            if (b <= 0) return -1;
            if (b <= 1) b = b * 100;
            return Math.round(b);
        }

        // A disconnected device always goes through the same helper. It skips
        // pairing for an existing bond, but still stops discovery and repairs a
        // stale bond when BlueZ can no longer bring it up.
        function activateDevice(d) {
            if (!d)
                return;
            if (d.connected) {
                if (typeof d.disconnect === "function")
                    d.disconnect();
                return;
            }
            bt.pairDevice(d);
        }

        function pairDevice(d) {
            if (!d || !d.address || pairProc.running)
                return;
            if (bt.adapter && bt.adapter.discovering)
                bt.adapter.discovering = false;
            bt.pairingAddress = d.address;
            bt.failedAddress = "";
            pairProc.command = ["ryoku-bluetooth-link", d.address];
            pairProc.running = true;
        }

        // Keep the fresh-install default on, but persist every explicit choice.
        // The helper can recover a soft-blocked radio before BlueZ has an adapter.
        function setAdapterEnabled(v) {
            Quickshell.execDetached(["ryoku-bluetooth-power", v ? "on" : "off"]);
        }

        function startService() {
            if (svcProc.running)
                return;
            bt.serviceError = "";
            svcProc.running = true;
        }

        // leaving the subtab (or closing the hub) mid-scan stops discovery so
        // BlueZ isn't left chewing the radio in the background.
        Component.onDestruction: {
            if (bt.adapter && bt.adapter.discovering)
                bt.adapter.discovering = false;
        }

        // armed by BlueZ confirming the scan, not by the write that asked for
        // it, so a start that lands late still gets its stop.
        Timer {
            id: scanTimer
            interval: 25000
            repeat: false
            running: bt.discovering
            onTriggered: if (bt.adapter) bt.adapter.discovering = false
        }

        Timer {
            id: failTimer
            interval: 4000
            repeat: false
            onTriggered: bt.failedAddress = ""
        }

        Process {
            id: rfkillState
            command: ["rfkill", "-n", "-o", "TYPE,SOFT,HARD", "list", "bluetooth"]
            running: true
            stdout: StdioCollector {
                onStreamFinished: {
                    const rows = text.trim().split("\n").map(line => line.trim().split(/\s+/))
                        .filter(fields => fields[0] === "bluetooth");
                    bt.softBlocked = rows.some(fields => fields[1] === "blocked");
                    bt.hardBlocked = rows.some(fields => fields[2] === "blocked");
                }
            }
        }

        // WirePlumber's own setting, read and written through ryoku-bt-audio;
        // unknown until the first read lands, so a missing helper or a stopped
        // WirePlumber leaves the row disabled with the reason shown.
        property bool micKnown: false
        property bool micOn: true

        function setMic(on) {
            if (!bt.micKnown || micWrite.running)
                return;
            micWrite.command = ["ryoku-bt-audio", "mic", on ? "on" : "off"];
            micWrite.running = true;
        }

        Process {
            id: micRead
            command: ["ryoku-bt-audio", "mic"]
            running: true
            stdout: StdioCollector { id: micOut }
            onExited: function(exitCode) {
                var v = micOut.text.trim();
                bt.micKnown = exitCode === 0 && (v === "on" || v === "off");
                if (bt.micKnown)
                    bt.micOn = v === "on";
            }
        }

        Process {
            id: micWrite
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: micRead.running = true
        }

        Process {
            id: pairProc
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: function(exitCode) {
                var addr = bt.pairingAddress;
                bt.pairingAddress = "";
                if (exitCode !== 0) {
                    bt.failedAddress = addr;
                    failTimer.restart();
                }
            }
        }


        // revive a stopped bluetoothd. pkexec raises the polkit prompt;
        // enable --now so it also survives the next boot.
        Process {
            id: svcProc
            command: ["pkexec", "ryoku-host", "svc", "--system", "enable", "--now", "bluetooth"]
            stdout: StdioCollector {}
            stderr: StdioCollector {}
            onExited: function(exitCode) {
                if (exitCode !== 0) {
                    bt.serviceError = I18n.tr("Could not start the bluetooth service.");
                    svcErrTimer.restart();
                }
            }
        }

        Timer {
            id: svcErrTimer
            interval: 6000
            repeat: false
            onTriggered: bt.serviceError = ""
        }

        Item {
            id: btContent
            anchors.fill: parent

            Item {
                id: btHeader
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                height: 48

                Row {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Tokens.s3

                    BtRune {
                        anchors.verticalCenter: parent.verticalCenter
                        tint: bt.adapterOn ? Tokens.ink : Tokens.inkMuted
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: I18n.tr("BLUETOOTH")
                        color: Tokens.ink
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fMicro
                        font.weight: Font.Medium
                        font.letterSpacing: Tokens.trackMark
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: bt.adapterOn
                        text: {
                            var known = bt.devices.length;
                            if (known === 0)
                                return bt.discovering ? I18n.tr("Scanning\u2026") : I18n.tr("No devices yet");
                            if (bt.connectedCount > 0)
                                return I18n.tr("%1 connected \u00b7 %2 known").arg(bt.connectedCount).arg(known);
                            return I18n.tr("%1 known").arg(known);
                        }
                        color: Tokens.inkMuted
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fSmall
                        font.weight: Font.Medium
                    }
                }

                Row {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Tokens.s3

                    // scan toggle (visible only while the adapter is on).
                    // discovering inverts the button (bone) to read as the ON
                    // state; tapping re-arms the 25s timer.
                    Btn {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: bt.adapterOn
                        text: bt.discovering ? I18n.tr("Scanning\u2026") : I18n.tr("Scan")
                        primary: bt.discovering
                        onAct: {
                            if (!bt.adapter)
                                return;
                            bt.adapter.discovering = !bt.adapter.discovering;
                        }
                    }

                    // A platform rfkill switch can remove the adapter from
                    // BlueZ. Keep the switch available for a recoverable soft block.
                    Sw {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: bt.hasAdapter || bt.softBlocked
                        on: bt.adapterOn
                        onToggled: (v) => bt.setAdapterEnabled(v)
                    }
                }
            }

            Rectangle {
                id: btRule
                anchors.top: btHeader.bottom
                anchors.topMargin: Tokens.s2
                anchors.left: parent.left
                anchors.right: parent.right
                height: 1
                color: Tokens.lineSoft
            }

            Item {
                id: btBodyArea
                anchors.top: btRule.bottom
                anchors.topMargin: Tokens.s5
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: btMicRow.top
                anchors.bottomMargin: btMicRow.visible ? Tokens.s3 : 0

                // off / empty placeholder, centred so the page never looks broken.
                Column {
                    anchors.centerIn: parent
                    visible: !bt.hasAdapter || !bt.adapterOn || bt.devices.length === 0
                    spacing: Tokens.s3

                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: bt.blocked ? I18n.tr("Bluetooth is blocked.")
                            : !bt.hasAdapter ? I18n.tr("Bluetooth isn't available.")
                            : !bt.adapterOn ? I18n.tr("Bluetooth is off.")
                            : (bt.discovering ? I18n.tr("Scanning\u2026") : I18n.tr("No devices yet."))
                        color: Tokens.inkDim
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fRow
                        font.weight: Font.Medium
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        visible: !bt.hasAdapter || !bt.adapterOn || (!bt.discovering && bt.devices.length === 0)
                        text: bt.softBlocked ? I18n.tr("The radio is software blocked; the toggle unblocks it.")
                            : bt.hardBlocked ? I18n.tr("The radio is off at the hardware level.")
                            : !bt.hasAdapter ? I18n.tr("The bluetooth service (bluez) isn't running.")
                            : !bt.adapterOn ? I18n.tr("Turn the adapter on to see nearby and paired devices.")
                            : I18n.tr("Hit Scan to discover nearby devices.")
                        color: Tokens.inkMuted
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fSmall
                        font.weight: Font.Medium
                    }

                    // service repair, shown only when org.bluez is missing entirely.
                    Btn {
                        anchors.horizontalCenter: parent.horizontalCenter
                        visible: !bt.hasAdapter && !bt.blocked
                        text: svcProc.running ? I18n.tr("Starting\u2026") : I18n.tr("Start service")
                        armed: !svcProc.running
                        onAct: bt.startService()
                    }

                    ErrChip {
                        anchors.horizontalCenter: parent.horizontalCenter
                        visible: bt.serviceError.length > 0
                        text: bt.serviceError
                    }
                }

                Flickable {
                    id: devFlick
                    visible: bt.adapterOn && bt.devices.length > 0
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    anchors.left: parent.left
                    anchors.right: parent.right
                    contentWidth: width
                    contentHeight: devCol.implicitHeight + 8
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: ScrollRail { policy: ScrollBar.AsNeeded }
                    WheelScroll { }

                    Column {
                        id: devCol
                        width: devFlick.width - Tokens.s3
                        spacing: Tokens.s2

                        Repeater {
                            model: bt.devicesSorted

                            delegate: Column {
                                id: dev

                                required property var modelData
                                readonly property bool isConnected: modelData ? modelData.connected === true : false
                                readonly property bool isPaired: modelData ? modelData.paired === true : false
                                readonly property string addr: (modelData && modelData.address) ? modelData.address : ""
                                readonly property bool pairing: addr.length > 0 && bt.pairingAddress === addr
                                readonly property bool failed: addr.length > 0 && bt.failedAddress === addr
                                readonly property int battery: bt.batteryLevel(modelData)

                                width: parent.width
                                spacing: 4

                                // connection is set membership, not an exclusive
                                // ON, so it is marked by the word and an ink
                                // border rather than a full inversion.
                                Rectangle {
                                    id: tile
                                    width: parent.width
                                    height: 64
                                    radius: Tokens.radius
                                    color: rowHov.hovered ? Tokens.tint5 : "transparent"
                                    border.width: Tokens.border
                                    border.color: dev.isConnected ? Tokens.ink
                                        : (rowHov.hovered ? Tokens.lineStrong : Tokens.line)
                                    Behavior on color { ColorAnimation { duration: Tokens.snap } }
                                    Behavior on border.color { ColorAnimation { duration: Tokens.snap } }

                                    HoverHandler { id: rowHov; cursorShape: Qt.PointingHandCursor }
                                    TapHandler { onTapped: bt.activateDevice(dev.modelData) }

                                    Rectangle {
                                        id: iconTile
                                        anchors.left: parent.left
                                        anchors.leftMargin: Tokens.s3
                                        anchors.verticalCenter: parent.verticalCenter
                                        width: 40
                                        height: 40
                                        radius: Tokens.radius
                                        color: "transparent"
                                        border.width: Tokens.border
                                        border.color: dev.isConnected ? Tokens.line : Tokens.lineSoft

                                        BtRune {
                                            anchors.centerIn: parent
                                            span: 18
                                            tint: dev.isConnected ? Tokens.ink : Tokens.inkMuted
                                        }
                                    }

                                    Column {
                                        anchors.left: iconTile.right
                                        anchors.leftMargin: Tokens.s3
                                        anchors.right: devRight.left
                                        anchors.rightMargin: Tokens.s3
                                        anchors.verticalCenter: parent.verticalCenter
                                        spacing: 2

                                        Text {
                                            width: parent.width
                                            text: BtName.label(dev.modelData) || I18n.tr("Unknown")
                                            color: Tokens.ink
                                            font.family: Tokens.ui
                                            font.pixelSize: Tokens.fBody
                                            font.weight: dev.isConnected ? Font.DemiBold : Font.Medium
                                            elide: Text.ElideRight
                                        }
                                        Text {
                                            width: parent.width
                                            visible: text.length > 0
                                            text: dev.pairing ? I18n.tr("pairing\u2026") : bt.metaFor(dev.modelData)
                                            color: Tokens.inkMuted
                                            font.family: Tokens.ui
                                            font.pixelSize: Tokens.fMicro
                                            font.weight: Font.Medium
                                            elide: Text.ElideRight
                                        }
                                    }

                                    Row {
                                        id: devRight
                                        anchors.right: parent.right
                                        anchors.rightMargin: Tokens.s3
                                        anchors.verticalCenter: parent.verticalCenter
                                        spacing: Tokens.s2

                                        PulseDot {
                                            anchors.verticalCenter: parent.verticalCenter
                                            on: dev.pairing
                                        }

                                        // battery pill (connected + has a level).
                                        Rectangle {
                                            anchors.verticalCenter: parent.verticalCenter
                                            visible: dev.isConnected && dev.battery >= 0
                                            radius: Tokens.radius
                                            color: "transparent"
                                            border.width: Tokens.border
                                            border.color: Tokens.line
                                            height: 22
                                            width: battTxt.implicitWidth + 18

                                            Text {
                                                id: battTxt
                                                anchors.centerIn: parent
                                                text: Math.max(0, dev.battery) + "%"
                                                color: Tokens.ink
                                                font.family: Tokens.ui
                                                font.pixelSize: Tokens.fMicro
                                                font.weight: Font.Medium
                                                font.features: ({ "tnum": 1 })
                                            }
                                        }

                                        MiniPill {
                                            anchors.verticalCenter: parent.verticalCenter
                                            visible: !dev.isPaired && !dev.pairing
                                            text: I18n.tr("Pair")
                                            onAct: bt.activateDevice(dev.modelData)
                                        }

                                        MiniPill {
                                            anchors.verticalCenter: parent.verticalCenter
                                            visible: dev.isConnected
                                            text: I18n.tr("Disconnect")
                                            onAct: bt.activateDevice(dev.modelData)
                                        }
                                    }
                                }

                                ErrChip {
                                    visible: dev.failed
                                    x: 66
                                    text: I18n.tr("Pairing failed")
                                }
                            }
                        }
                    }
                }
            }

            Item {
                id: btMicRow
                visible: bt.hasAdapter
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: visible ? 56 : 0
                opacity: bt.micKnown ? 1 : 0.5

                Rectangle {
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: 1
                    color: Tokens.lineSoft
                }

                Column {
                    anchors.left: parent.left
                    anchors.right: micSw.left
                    anchors.rightMargin: Tokens.s3
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2

                    Text {
                        width: parent.width
                        text: I18n.tr("Switch headsets to call mode for the mic")
                        color: Tokens.ink
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fBody
                        font.weight: Font.Medium
                        elide: Text.ElideRight
                    }

                    Text {
                        width: parent.width
                        text: !bt.micKnown ? I18n.tr("Needs WirePlumber running and wpctl installed.")
                            : bt.micOn ? I18n.tr("Sound turns mono while an app uses the mic.")
                            : I18n.tr("Headsets stay in stereo; their mic is not offered to apps.")
                        color: Tokens.inkMuted
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fSmall
                        font.weight: Font.Medium
                        elide: Text.ElideRight
                    }
                }

                Sw {
                    id: micSw
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    enabled: bt.micKnown && !micWrite.running
                    on: bt.micOn
                    onToggled: (v) => bt.setMic(v)
                }
            }
        }
    }

    // ── Hotspot subtab ───────────────────────────────────────────────────────

    // brings the persistent RyokuHotspot NetworkManager profile up/down through
    // nmcli, with an editable SSID + WPA2 password. state and credentials read
    // straight from NM on entry. name + password ride in as positional args,
    // NEVER spliced into the shell string.
    component HotspotBody: Item {
        id: hs

        readonly property var devices: (typeof Networking !== "undefined" && Networking && Networking.devices) ? Networking.devices.values : []
        readonly property var wifiDev: hs.devices.find(function(d) { return d && d.type === DeviceType.Wifi }) || null

        readonly property string hsCon: "RyokuHotspot"
        readonly property string hsIface: hs.wifiDev ? (hs.wifiDev.name || "wlan0") : "wlan0"
        property string hsName: "Ryoku"
        property string hsPw: ""
        property bool hsActive: false
        property bool hsBusy: false
        property string hsEdit: ""
        property string hsDraft: ""

        function applyHotspot() {
            if (hs.hsBusy || hs.hsPw.length < 8)
                return;
            hs.hsBusy = true;
            hsApplyProc.command = ["sh", "-c",
                'c="' + hs.hsCon + '"; '
                + 'if nmcli -t connection show "$c" >/dev/null 2>&1; then '
                +   'nmcli connection modify "$c" 802-11-wireless.ssid "$1" 802-11-wireless-security.key-mgmt wpa-psk 802-11-wireless-security.psk "$2"; '
                + 'else '
                +   'nmcli connection add type wifi ifname "$3" con-name "$c" autoconnect no 802-11-wireless.ssid "$1" 802-11-wireless.mode ap 802-11-wireless-security.key-mgmt wpa-psk 802-11-wireless-security.psk "$2" ipv4.method shared; '
                + 'fi; '
                + 'nmcli connection up "$c"',
                "sh", hs.hsName, hs.hsPw, hs.hsIface];
            hsApplyProc.running = true;
        }

        function stopHotspot() {
            if (hs.hsBusy)
                return;
            hs.hsBusy = true;
            hsDownProc.running = true;
        }

        function refreshHotspot() {
            hsStateProc.running = true;
            hsReadProc.running = true;
        }

        // commit an inline name or password edit. a password shorter than the
        // WPA2 8-char minimum is dropped silently. a live hotspot re-applies so
        // the change takes effect at once.
        function commitHotspotEdit() {
            if (hs.hsEdit === "name") {
                if (hs.hsDraft.length)
                    hs.hsName = hs.hsDraft;
            } else if (hs.hsEdit === "pw") {
                if (hs.hsDraft.length >= 8)
                    hs.hsPw = hs.hsDraft;
            }
            hs.hsEdit = "";
            hs.hsDraft = "";
            if (hs.hsActive)
                hs.applyHotspot();
        }

        // 8-char WPA2 password from an unambiguous alphabet (no 0/O/1/l/I).
        function generatePw() {
            var cs = "abcdefghijkmnpqrstuvwxyz23456789";
            var s = "";
            for (var i = 0; i < 8; i++)
                s += cs.charAt(Math.floor(Math.random() * cs.length));
            return s;
        }

        Component.onCompleted: hs.refreshHotspot()

        Process {
            id: hsApplyProc
            onExited: {
                hs.hsBusy = false;
                hs.refreshHotspot();
            }
        }

        Process {
            id: hsDownProc
            command: ["nmcli", "connection", "down", hs.hsCon]
            onExited: {
                hs.hsBusy = false;
                hs.refreshHotspot();
            }
        }

        Process {
            id: hsStateProc
            command: ["sh", "-c", "nmcli -t -f NAME connection show --active | grep -qxF -- \"$1\" && echo on || echo off", "sh", hs.hsCon]
            stdout: StdioCollector {
                onStreamFinished: hs.hsActive = this.text.trim() === "on"
            }
        }

        Process {
            id: hsReadProc
            command: ["nmcli", "-t", "-s", "-g", "802-11-wireless.ssid,802-11-wireless-security.psk", "connection", "show", hs.hsCon]
            stdout: StdioCollector {
                onStreamFinished: {
                    var lines = this.text.split("\n");
                    if (lines.length >= 1 && lines[0].length)
                        hs.hsName = lines[0];
                    if (lines.length >= 2 && lines[1].length)
                        hs.hsPw = lines[1];
                }
            }
        }

        Column {
            id: hsHead
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            spacing: Tokens.s2

            Text {
                text: I18n.tr("Share this machine's connection as a Wi-Fi hotspot. NetworkManager owns the profile (named %1); changes to the network name or password apply at once when the hotspot is live.").arg(hs.hsCon)
                color: Tokens.inkMuted
                font.family: Tokens.ui
                font.pixelSize: Tokens.fSmall
                font.weight: Font.Medium
                width: Math.min(parent.width, 720)
                wrapMode: Text.WordWrap
            }
        }

        Column {
            id: hsForm
            anchors.left: parent.left
            anchors.right: parent.right
            // the gutter the scrolling tabs keep for their scroll rail
            anchors.rightMargin: Tokens.s4
            anchors.top: hsHead.bottom
            anchors.topMargin: Tokens.s6
            spacing: Tokens.s5

            // big toggle card: glyph, label, live status, switch. active is a
            // boolean ON marked by the word + an ink border (the Sw knob also
            // reads ON); no full inversion.
            Rectangle {
                width: parent.width
                height: 76
                radius: Tokens.radius
                color: "transparent"
                border.width: Tokens.border
                border.color: hs.hsActive ? Tokens.ink : Tokens.line
                Behavior on border.color { ColorAnimation { duration: Tokens.snap } }

                WifiGlyph {
                    id: hsGlyph
                    anchors.left: parent.left
                    anchors.leftMargin: Tokens.s5
                    anchors.verticalCenter: parent.verticalCenter
                    tint: hs.hsActive ? Tokens.ink : Tokens.inkMuted
                }

                Column {
                    anchors.left: hsGlyph.right
                    anchors.leftMargin: Tokens.s3
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2

                    Text {
                        text: I18n.tr("Hotspot")
                        color: Tokens.ink
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fRow
                        font.weight: Font.DemiBold
                    }
                    Text {
                        text: hs.hsBusy ? I18n.tr("Working\u2026")
                            : (hs.hsActive ? I18n.tr("Active on %1").arg(hs.hsIface) : I18n.tr("Off"))
                        color: hs.hsActive ? Tokens.ink : Tokens.inkMuted
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fSmall
                        font.weight: Font.Medium
                    }
                }

                Sw {
                    anchors.right: parent.right
                    anchors.rightMargin: Tokens.s5
                    anchors.verticalCenter: parent.verticalCenter
                    on: hs.hsActive
                    enabled: !hs.hsBusy
                    opacity: hs.hsBusy ? 0.3 : 1
                    onToggled: {
                        if (hs.hsActive) {
                            hs.stopHotspot();
                        } else {
                            if (hs.hsPw.length < 8)
                                hs.hsPw = hs.generatePw();
                            hs.applyHotspot();
                        }
                    }
                }
            }

            // credentials.
            Column {
                width: parent.width
                spacing: Tokens.s3

                Row {
                    width: parent.width
                    spacing: Tokens.s2
                    Rectangle { width: 4; height: 4; color: Tokens.ink; anchors.verticalCenter: parent.verticalCenter }
                    Text {
                        text: I18n.tr("DETAILS")
                        color: Tokens.ink
                        font.family: Tokens.ui
                        font.pixelSize: Tokens.fMicro
                        font.weight: Font.Medium
                        font.letterSpacing: Tokens.trackMark
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Rectangle {
                        width: Math.max(0, parent.parent.width - 100)
                        height: 1
                        color: Tokens.lineSoft
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }

                CredRow {
                    width: parent.width
                    field: "name"
                    label: I18n.tr("Network name")
                    value: hs.hsName
                    placeholder: "Ryoku"
                    editing: hs.hsEdit === "name"
                    draft: hs.hsDraft
                    onBeginEdit: { hs.hsDraft = value; hs.hsEdit = "name"; }
                    onDraftEdited: (v) => hs.hsDraft = v
                    onCommit: hs.commitHotspotEdit()
                    onCancel: { hs.hsEdit = ""; hs.hsDraft = ""; }
                }

                CredRow {
                    width: parent.width
                    field: "pw"
                    label: I18n.tr("Password")
                    value: hs.hsPw
                    placeholder: I18n.tr("Tap to set")
                    secret: true
                    editing: hs.hsEdit === "pw"
                    draft: hs.hsDraft
                    onBeginEdit: { hs.hsDraft = value; hs.hsEdit = "pw"; }
                    onDraftEdited: (v) => hs.hsDraft = v
                    onCommit: hs.commitHotspotEdit()
                    onCancel: { hs.hsEdit = ""; hs.hsDraft = ""; }
                }
            }
        }
    }

    Component { id: wifiComp; WifiBody {} }
    Component { id: btComp; BtBody {} }
    Component { id: hsComp; HotspotBody {} }

    // a faint 接続 watermark dresses the whole page, like every section
    Watermark { anchors.fill: parent; text: "\u63a5\u7d9a" }

    // ── layout: head, bone-pill tab strip, body ─────────────────────────────
    Item {
        id: content
        anchors.fill: parent
        anchors.margins: Tokens.s6

        // head: eyebrow, Fraunces title, blurb (matches every page).
        Column {
            id: head
            anchors { left: parent.left; right: parent.right; top: parent.top }
            // the register row sits off the title: a rule over a 32px
            // title needs more than the gap between two lines of body text
            spacing: Tokens.s3

            Row {
                // the register row holds a fixed box, so the rule and the seal keep
                // their distance from the title on every page
                height: Tokens.s5
                spacing: Tokens.s2
                Rectangle {
                    width: 16; height: 1; color: Tokens.ink
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: UiPreferences.brandMark("\u529b"); color: Tokens.ink; font.family: Tokens.jp
                    font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: I18n.tr("DEVICES"); color: Tokens.inkMuted; font.family: Tokens.ui
                    font.pixelSize: 9; font.weight: Font.Medium; font.letterSpacing: Tokens.trackMark
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            Text {
                text: I18n.tr("Connections"); color: Tokens.ink
                font.family: Tokens.display; font.pixelSize: Tokens.fTitle
            }
            Text {
                width: Math.min(parent.width, 720)
                text: I18n.tr("Wi-Fi, Ethernet, Bluetooth, hotspot, VPN, DNS and phone connections, applied live.")
                color: Tokens.inkMuted; font.family: Tokens.ui
                font.pixelSize: Tokens.fBody; wrapMode: Text.WordWrap
            }
        }

        // The kill switch is a machine-wide firewall, not a radio toggle. The
        // copy names SSH because an activated switch severs remote sessions too.
        Rectangle {
            id: killSwitch
            anchors { left: parent.left; right: parent.right; rightMargin: Tokens.s5; top: head.bottom; topMargin: Tokens.s4 }
            implicitHeight: killCopy.implicitHeight + Tokens.s4
            radius: Tokens.radius
            color: pg.killActive ? Tokens.bone : "transparent"
            border.width: Tokens.border
            border.color: pg.killActive ? Tokens.bone : Tokens.line

            Column {
                id: killCopy
                anchors { left: parent.left; right: killAction.left; rightMargin: Tokens.s4; verticalCenter: parent.verticalCenter; leftMargin: Tokens.s3 }
                spacing: Tokens.s1
                Text {
                    text: pg.killActive ? I18n.tr("INTERNET ISOLATED") : I18n.tr("INTERNET KILL SWITCH")
                    color: pg.killActive ? Tokens.inkOnBone : Tokens.ink
                    font.family: Tokens.ui
                    font.pixelSize: Tokens.fMicro
                    font.weight: Font.Medium
                    font.letterSpacing: Tokens.trackMark
                }
                Text {
                    width: parent.width
                    text: pg.killState === "armed" ? I18n.tr("Firewall repair required before this machine is safe.")
                        : (pg.killState === "blocked" ? I18n.tr("Traffic is blocked but the boot guard is not armed.")
                        : I18n.tr("Blocks Wi-Fi, Ethernet, VPN, LAN and IPv4/IPv6. It also severs SSH."))
                    color: pg.killActive ? Tokens.inkOnBone : Tokens.inkMuted
                    font.family: Tokens.ui
                    font.pixelSize: Tokens.fMicro
                    wrapMode: Text.WordWrap
                }
                Text {
                    visible: pg.killError !== ""
                    text: pg.killError
                    color: pg.killActive ? Tokens.inkOnBone : Tokens.inkMuted
                    font.family: Tokens.ui
                    font.pixelSize: Tokens.fMicro
                    wrapMode: Text.WordWrap
                }
            }

            MiniPill {
                id: killAction
                anchors { right: parent.right; rightMargin: Tokens.s3; verticalCenter: parent.verticalCenter }
                text: pg.killBusy ? I18n.tr("WORKING") : (pg.killState === "off" ? I18n.tr("ISOLATE") : I18n.tr("RESTORE"))
                armed: !pg.killBusy && pg.killState !== "checking"
                onBone: pg.killActive
                onAct: pg.toggleKillSwitch()
            }
        }

        Text {
            id: killWarning
            anchors { left: killSwitch.left; right: killSwitch.right; top: killSwitch.bottom; topMargin: Tokens.s1 }
            visible: pg.killState === "off"
            text: I18n.tr("Use ISOLATE from the physical machine; every remote connection is cut immediately.")
            color: Tokens.inkFaint
            font.family: Tokens.ui
            font.pixelSize: Tokens.fMicro
            wrapMode: Text.WordWrap
        }


        // the shared Tabs plate: selection is the // lead on bone, no slider.
        Tabs {
            id: tabStrip
            anchors { left: parent.left; top: killWarning.bottom; topMargin: Tokens.s4 }
            options: pg.tabs.map(function (t) { return t.label; })
            current: {
                for (var i = 0; i < pg.tabs.length; i++)
                    if (pg.tabs[i].key === pg.sub) return pg.tabs[i].label;
                return pg.tabs[0].label;
            }
            onChose: (label) => {
                for (var i = 0; i < pg.tabs.length; i++)
                    if (pg.tabs[i].label === label) { pg.sub = pg.tabs[i].key; break; }
            }
        }

        // body: swaps source on tab change; the outgoing tab is destroyed, so
        // each body re-reads state and stops its own scan (as in the old page).
        // an unrecognised sub falls through to Hotspot, preserving old behaviour.
        Loader {
            id: body
            anchors {
                left: parent.left
                right: parent.right
                rightMargin: 0
                top: tabStrip.bottom; bottom: parent.bottom
                topMargin: Tokens.s5
            }
            opacity: pg.onFileTab ? 0 : 1
            x: pg.onFileTab ? -Tokens.s3 : 0
            visible: opacity > 0.01
            Behavior on opacity {
                enabled: !Tokens.reduceMotion
                NumberAnimation { duration: Tokens.durSmall; easing.type: Easing.OutCubic }
            }
            Behavior on x {
                enabled: !Tokens.reduceMotion
                NumberAnimation { duration: Tokens.durSmall; easing.type: Easing.OutCubic }
            }
            sourceComponent: pg.sub === "wifi" ? wifiComp
                : pg.sub === "bluetooth" ? btComp : hsComp
        }

        Loader {
            anchors {
                left: parent.left
                right: parent.right
                top: tabStrip.bottom
                bottom: parent.bottom
                topMargin: Tokens.s5
            }
            active: pg.onFileTab
            source: pg.onFileTab ? Qt.resolvedUrl(pg.fileTabs[pg.sub]) : ""
            opacity: pg.onFileTab ? 1 : 0
            x: pg.onFileTab ? 0 : Tokens.s3
            visible: opacity > 0.01
            Behavior on opacity {
                enabled: !Tokens.reduceMotion
                NumberAnimation { duration: Tokens.durSmall; easing.type: Easing.OutCubic }
            }
            Behavior on x {
                enabled: !Tokens.reduceMotion
                NumberAnimation { duration: Tokens.durSmall; easing.type: Easing.OutCubic }
            }
        }

    }
}
