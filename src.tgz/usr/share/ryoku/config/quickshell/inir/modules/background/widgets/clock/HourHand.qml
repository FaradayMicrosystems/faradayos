pragma ComponentBehavior: Bound

import inir.modules.common
import QtQuick

Item {
    id: root

    required property int clockHour
    required property int clockMinute
    property real handLength: 72
    property real handWidth: 20
    property string style: "fill"
    property color color: Appearance.colors.colPrimary

    property real fillColorAlpha: root.style === "hollow" ? 0 : 1
    Behavior on fillColorAlpha {
        animation: NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
    }

    rotation: -90 + (360 / 12) * (root.clockHour + root.clockMinute / 60)
    Behavior on rotation {
        animation: RotationAnimation {
            direction: RotationAnimation.Clockwise
            duration: Appearance.animation.elementMoveFast.duration
            easing.type: Appearance.animation.elementMoveFast.type
            easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve
        }
    }

    Rectangle {
        anchors.verticalCenter: parent.verticalCenter
        x: (parent.width - root.handWidth) / 2 - 15 * (root.style === "classic")
        width: root.handLength
        height: root.style === "classic" ? 8 : root.handWidth
        radius: root.style === "classic" ? 2 : root.handWidth / 2
        color : Qt.rgba(root.color.r, root.color.g, root.color.b, root.fillColorAlpha)
        border.color: root.color
        border.width: 4

        Behavior on height {
            animation: NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
        }
        Behavior on x {
            animation: NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
        }
    }
}
