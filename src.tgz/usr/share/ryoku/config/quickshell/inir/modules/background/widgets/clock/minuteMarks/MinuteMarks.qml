pragma ComponentBehavior: Bound

import inir.modules.common
import inir.modules.common.widgets
import QtQuick

Item {
    id: root

    property color color: Appearance.colors.colOnSecondaryContainer
    property string style: Config.getNestedValue("background.widgets.clock.cookie.dialNumberStyle", "full") // "dots", "numbers", "full", "hide"
    property string dateStyle : Config.getNestedValue("background.widgets.clock.cookie.dateStyle", "bubble")

    // 12 Dots
    FadeLoader {
        id: dotsLoader
        anchors {
            fill: parent
            margins: 10
        }
        shown: root.style === "dots"
        sourceComponent: Dots {
            color: root.color
            margins: 46 - dotsLoader.opacity * 34
        }
    }

    // 3-6-9-12 hour numbers (pls don't realize you can have more than 4 numbers)
    FadeLoader {
        id: bigHourNumbersLoader
        anchors.fill: parent
        shown: root.style === "numbers"
        sourceComponent: BigHourNumbers {
            numberSize: 80
            color: root.color
            margins: 20 - 10 * bigHourNumbersLoader.opacity
        }
    }

    // Lines
    FadeLoader {
        id: linesLoader
        anchors {
            fill: parent
            margins: 10
        }
        shown: root.style === "full"
        sourceComponent: Lines {
            color: root.color
            margins: 46 - linesLoader.opacity * 34
        }
    }
    
}
